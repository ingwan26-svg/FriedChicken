package com.catatanusaha.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private static final int CREATE_FILE = 4102;
  private String pendingText = "";
  private String pendingMime = "text/plain";
  private String pendingName = "catatan-usaha.txt";
  private WebView web;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    web = new WebView(this);
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new AppBridge(), "Android");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  private class AppBridge {
    @JavascriptInterface public void saveText(String text, String mime, String filename) {
      runOnUiThread(() -> {
        pendingText = text == null ? "" : text;
        pendingMime = (mime == null || mime.isEmpty()) ? "text/plain" : mime;
        pendingName = (filename == null || filename.isEmpty()) ? "catatan-usaha.txt" : filename;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(pendingMime.contains("json") ? "application/json" : (pendingMime.contains("csv") ? "text/csv" : "text/plain"));
        intent.putExtra(Intent.EXTRA_TITLE, pendingName);
        startActivityForResult(intent, CREATE_FILE);
      });
    }
    @JavascriptInterface public void printPage() {
      runOnUiThread(() -> {
        try {
          PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
          android.print.PrintDocumentAdapter adapter = web.createPrintDocumentAdapter("Laporan-Catatan-Usaha-Ayam");
          manager.print("Laporan Catatan Usaha", adapter, new PrintAttributes.Builder().build());
        } catch (Exception e) {
          Toast.makeText(MainActivity.this, "Fitur cetak tidak tersedia pada perangkat ini.", Toast.LENGTH_LONG).show();
        }
      });
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == CREATE_FILE && resultCode == RESULT_OK && data != null) {
      Uri uri = data.getData();
      try (OutputStream out = getContentResolver().openOutputStream(uri)) {
        if (out != null) out.write(pendingText.getBytes(StandardCharsets.UTF_8));
        Toast.makeText(this, "File berhasil disimpan.", Toast.LENGTH_LONG).show();
      } catch (Exception e) {
        Toast.makeText(this, "Gagal menyimpan file. Coba pilih folder lain.", Toast.LENGTH_LONG).show();
      }
    }
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }
}
