# Catatan Usaha Ayam — Android offline

Aplikasi Android WebView offline yang disesuaikan dari template Excel UMKM Ayam Fried Chicken.

## Modul
- Master Barang/Menu: kode, kategori, satuan, stok awal/minimum, modal, harga jual; contoh dapat diedit.
- Penjualan: tanggal, jumlah, diskon, metode pembayaran, riwayat.
- Resep: komposisi bahan per porsi; stok bahan berkurang otomatis saat menu dijual.
- Pembelian: menambah stok bahan/barang.
- Biaya operasional.
- Laporan stok dan peringatan stok minimum.
- Laporan periode, ringkasan laba rugi, grafik omzet 7 hari.
- Ekspor CSV (dibuka di Excel/Sheets), cetak/simpan PDF lewat dialog cetak Android, backup/pulihkan JSON.

## Data contoh
Data awal contoh mengikuti template: Ayam Fried Chicken, ayam mentah, tepung bumbu, minyak goreng, kemasan, saus, dan resep satu porsi. Terdapat satu transaksi penjualan contoh yang dapat dihapus. Angka resep/modal hanya contoh; sesuaikan dengan bahan, ukuran porsi, dan harga nyata.

## Bangun APK
1. Unggah `source.zip` ke root repository GitHub.
2. Buat workflow `.github/workflows/build-apk.yml` di repository menggunakan file `build-apk-workflow.yml` yang disediakan terpisah.
3. Jalankan tab Actions > Build Catatan Usaha APK > Run workflow.
4. Unduh artifact `Catatan-Usaha-APK` setelah workflow sukses; ekstrak untuk mendapatkan `app-debug.apk`.

Data disimpan di localStorage WebView pada perangkat. Backup JSON secara berkala. Menghapus aplikasi dapat menghapus data lokal.
